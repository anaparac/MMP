This zip file contains short sequences with the backgrounds used to extract 
the silhouettes from original video sequences.
The m-file 'fname2bgname.m' relates between each original sequence and its 
matching background sequence.